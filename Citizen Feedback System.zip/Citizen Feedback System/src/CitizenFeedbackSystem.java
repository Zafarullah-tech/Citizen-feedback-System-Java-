// Import necessary libraries for GUI creation, event handling, file operations, date/time, data storage, and table management
import javax.swing.*;                            // For creating GUI components (like JFrame, JButton, etc.)
import java.awt.*;                               // For layout management and drawing GUI components
import java.awt.event.*;                         // For handling events like button clicks, key presses, etc.
import java.io.*;                                // For file input/output operations (read/write files)
import java.time.LocalDateTime;                  // For capturing and using the current date and time (e.g., timestamp for feedback)
import java.util.List;                           // For using the List interface (a type of collection)
import java.util.ArrayList;                      // For creating resizable arrays (ArrayList implements List)
import javax.swing.table.DefaultTableModel;      // For handling data in tables (JTable) using a customizable model
import java.io.File;                             // For file path representation and operations like checking file existence
import java.io.RandomAccessFile;                 // For reading and writing to a specific location in a file (random access)

// A utility class that holds the file paths used to store various types of data
final class FilePaths {
    public static final String CITIZENS = "citizens.txt";     // File to store registered citizen data (e.g., name, ID, etc.)
    public static final String FEEDBACKS = "feedbacks.txt";   // File to store feedback submitted by citizens
    public static final String RESPONSES = "responses.txt";   // File to store admin responses to feedback
    public static final String ADMINS = "admins.txt";         // File to store admin credentials or records
}

// Interface for database-like operations that all users will implement
interface DatabaseOperations {
    boolean save();    // Method to save the object data to a file
    boolean update();  // Method to update object data in the file
    boolean delete();  // Method to delete object data from the file
}

// Abstract class representing a general user (either citizen or admin)
abstract class User implements DatabaseOperations {
    protected String username;              // User's username
    protected String password;              // User's password
    protected String name;                  // User's full name
    protected String email;                 // User's email address
    protected String phone;                 // User's phone number
    protected LocalDateTime createdAt;      // Time when the user account was created

    // Constructor to initialize username, password, and name
    public User(String username, String password, String name) {
        this.username = username;                           // Set username
        this.password = password;                           // Set password
        this.name = name;                                   // Set name
        this.createdAt = LocalDateTime.now();               // Set current time as account creation time
    }

    // Getters and setters for each field (for accessing and modifying data)
    public String getUsername() { return username; }        // Get username
    public void setUsername(String username) { this.username = username; }  // Set username
    public String getPassword() { return password; }        // Get password
    public void setPassword(String password) { this.password = password; }  // Set password
    public String getName() { return name; }                // Get name
    public void setName(String name) { this.name = name; }  // Set name
    public String getEmail() { return email; }              // Get email
    public void setEmail(String email) { this.email = email; }              // Set email
    public String getPhone() { return phone; }              // Get phone number
    public void setPhone(String phone) { this.phone = phone; }              // Set phone number

    // Abstract method: login logic will be defined in subclasses (like Citizen or Admin)
    public abstract boolean login();
}

// Class for citizens that extends the User class
class Citizen extends User {
    private static int feedbackCount = 0;               // Shared counter for total feedbacks (static means shared by all instances)
    private List<Feedback> feedbacks;                   // List to store this citizen's feedback entries

    // Constructor to create a citizen object
    public Citizen(String username, String password, String name) {
        super(username, password, name);                // Call constructor of the parent class (User)
        this.feedbacks = new ArrayList<>();             // Initialize feedback list as an empty ArrayList
    }

    // Static method to get total feedback count
    public static int getFeedbackCount() {
        return feedbackCount;                           // Return number of feedbacks submitted
    }

    // Static method to increment feedback count when a new one is submitted
    public static void incrementFeedbackCount() {
        feedbackCount++;                                // Increase the feedback count by one
    }

    // Implementation of login method for Citizen
    @Override
    public boolean login() {
        // Try to read the citizens.txt file to check for valid username/password
        try (BufferedReader reader = new BufferedReader(new FileReader(FilePaths.CITIZENS))) {
            String line;
            while ((line = reader.readLine()) != null) {         // Read each line of the file
                String[] parts = line.split("\\|");              // Split the line using "|" as a separator
                if (parts.length >= 3 && parts[0].equals(username) && parts[1].equals(password)) {
                    // If username and password match, set remaining details
                    this.name = parts[2];                        // Set name
                    this.email = parts.length > 3 ? parts[3] : "";   // Set email if exists
                    this.phone = parts.length > 4 ? parts[4] : "";   // Set phone if exists
                    return true;                                 // Login successful
                }
            }
        } catch (IOException e) {
            // If any file reading error occurs, login fails
        }
        return false;                                            // Login failed
    }

    // Save this citizen's data to the citizens.txt file
    @Override
    public boolean save() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FilePaths.CITIZENS, true))) {
            // Write citizen data as a line in the file
            writer.write(username + "|" + password + "|" + name + "|" +
                    (email == null ? "" : email) + "|" +
                    (phone == null ? "" : phone));
            writer.newLine();                                    // Move to the next line for new entry
            return true;                                         // Save successful
        } catch (IOException e) {
            return false;                                        // Save failed due to error
        }
    }

    // Update citizen's data in citizens.txt
    @Override
    public boolean update() {
        File inputFile = new File(FilePaths.CITIZENS);           // Existing file with citizen data
        File tempFile = new File("citizens_temp.txt");           // Temporary file to store updated data
        boolean updated = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");              // Split each line to check username
                if (parts.length >= 3 && parts[0].equals(username)) {
                    // If this is the current user, write updated info
                    writer.write(username + "|" + password + "|" + name + "|" +
                            (email == null ? "" : email) + "|" +
                            (phone == null ? "" : phone));
                    updated = true;                              // Mark as updated
                } else {
                    writer.write(line);                          // Write original data for other users
                }
                writer.newLine();                                // Move to next line
            }
        } catch (IOException e) {
            return false;                                        // Update failed due to error
        }

        // Replace old file with the new one
        if (inputFile.delete() && tempFile.renameTo(inputFile)) {
            return updated;                                      // Return true if update was successful
        }
        return false;                                            // Failed to replace file or not updated
    }

    // Delete citizen's data from citizens.txt
    @Override
    public boolean delete() {
        File inputFile = new File(FilePaths.CITIZENS);           // Original data file
        File tempFile = new File("citizens_temp.txt");           // Temporary file
        boolean deleted = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");              // Split each line to check for this citizen
                if (parts.length >= 3 && parts[0].equals(username)) {
                    deleted = true;                              // Skip writing this line to delete it
                    continue;
                }
                writer.write(line);                              // Write other lines as is
                writer.newLine();                                // Next line
            }
        } catch (IOException e) {
            return false;                                        // Error while deleting
        }

        // Replace old file with the new one that excludes the deleted user
        if (inputFile.delete() && tempFile.renameTo(inputFile)) {
            return deleted;                                      // Return true if deletion was successful
        }
        return false;                                            // Deletion failed
    }
}

// Admin class that extends the User class
class Admin extends User {

    // Constructor: Initializes the Admin object with username, password, and role "Administrator"
    public Admin(String username, String password) {
        super(username, password, "Administrator"); // Call the superclass (User) constructor
    }

    // Override the login method to authenticate the admin from the admins.txt file
    @Override
    public boolean login() {
        // Try-with-resources: Open the file containing admin credentials
        try (BufferedReader reader = new BufferedReader(new FileReader(FilePaths.ADMINS))) {
            String line;
            // Read the file line by line
            while ((line = reader.readLine()) != null) {
                // Split each line by the delimiter '|'
                String[] parts = line.split("\\|");
                // Check if the line has at least username and password and they match this admin
                if (parts.length >= 2 && parts[0].equals(username) && parts[1].equals(password)) {
                    return true; // Return true if credentials match
                }
            }
        } catch (IOException e) {
            // Do nothing on exception (file not found or read error)
        }
        return false; // Return false if no match was found
    }

    // Override the save method to store admin credentials into the admins.txt file
    @Override
    public boolean save() {
        try {
            // Create a File object pointing to the admins.txt file
            File file = new File(FilePaths.ADMINS);
            boolean needsNewline = false; // Flag to check if a newline is needed

            // Check if the file exists and is not empty
            if (file.exists() && file.length() > 0) {
                // Open the file in read mode to check the last character
                try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
                    raf.seek(file.length() - 1); // Move to the last character
                    int last = raf.read(); // Read the last byte
                    // If the last character is not a newline or carriage return, set the flag
                    if (last != '\n' && last != '\r') needsNewline = true;
                }
            }

            // Open the file in append mode using BufferedWriter
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
                if (needsNewline) writer.newLine(); // Add a new line if needed
                // Write the admin's username and password in the format: username|password
                writer.write(username + "|" + password);
                writer.newLine(); // Move to next line
                return true; // Save successful
            }
        } catch (IOException e) {
            return false; // Return false if any error occurs
        }
    }

    // Override the update method — not implemented for Admin, returns false
    @Override
    public boolean update() {
        return false; // Admin update not supported in this implementation
    }

    // Override the delete method to remove this admin from the admins.txt file
    @Override
    public boolean delete() {
        // File pointing to the original admin file
        File inputFile = new File(FilePaths.ADMINS);
        // Temporary file where updated content will be written
        File tempFile = new File("admins_temp.txt");
        boolean deleted = false; // Flag to indicate if deletion was successful

        try (
                // Open original file for reading
                BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                // Open temporary file for writing
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))
        ) {
            String line;
            // Read each line from the original file
            while ((line = reader.readLine()) != null) {
                // Split the line into parts using '|'
                String[] parts = line.split("\\|");
                // If the username matches the current admin, skip this line (i.e., delete it)
                if (parts.length >= 2 && parts[0].equals(username)) {
                    deleted = true; // Mark deletion as done
                    continue; // Skip writing this line to the temp file
                }
                writer.write(line); // Write the line to the temp file
                writer.newLine(); // Keep formatting
            }
        } catch (IOException e) {
            return false; // Return false if an error occurs
        }

        // Replace the original file with the updated temp file
        if (inputFile.delete() && tempFile.renameTo(inputFile)) {
            return deleted; // Return true if admin was deleted
        }
        return false; // Return false if file replacement failed
    }
}
// Feedback class with image support
class Feedback implements DatabaseOperations {
    private int id; // Feedback ID
    private String username; // Citizen username
    private String message; // Feedback message
    private String status; // Feedback status
    private LocalDateTime createdAt; // Creation time
    private List<AdminResponse> responses; // List of admin responses
    private String imageFilename; // Image filename (null if no image)

    public Feedback(String username, String message) {
        this.username = username; // Assign the provided username to the class field 'username'
        this.message = message != null ? message : ""; // If 'message' is not null, assign it; otherwise, assign an empty string to avoid null values
        this.status = "Pending"; // Set the initial status of feedback to "Pending" by default
        this.createdAt = LocalDateTime.now(); // Set the 'createdAt' field to the current date and time
        this.responses = new ArrayList<>(); // Initialize 'responses' as an empty list to hold admin replies later
        this.id = generateId(); // Call the 'generateId()' method to get a unique ID and assign it to 'id'
        this.imageFilename = null; // Initialize 'imageFilename' as null, meaning no image attached yet
    }


    // Overloaded constructor for loading from file
    public Feedback(int id, String username, String message, String status, LocalDateTime createdAt, String imageFilename) {
        this.id = id; // Set the feedback ID from the given parameter
        this.username = username; // Set the username from the given parameter
        this.message = message != null ? message : ""; // If message is not null, assign it; otherwise, assign an empty string
        this.status = status; // Set the feedback status from the given parameter
        this.createdAt = createdAt; // Set the creation date and time from the given parameter
        this.responses = new ArrayList<>(); // Initialize the responses list as empty (no responses loaded here)
        this.imageFilename = imageFilename; // Set the image filename (can be null if no image)
    }


    // Generate a unique ID for feedback
    private int generateId() {
        int maxId = 0; // Initialize maxId to zero to keep track of the highest ID found

        // Try-with-resources to open the feedback file for reading safely
        try (BufferedReader reader = new BufferedReader(new FileReader(FilePaths.FEEDBACKS))) {
            String line; // Variable to hold each line read from the file

            // Read each line until end of file
            while ((line = reader.readLine()) != null) {
                // Split the line into parts using '|' as delimiter
                String[] parts = line.split("\\|");

                // Check if line contains any parts
                if (parts.length > 0) {
                    try {
                        // Parse the first part as an integer ID
                        int currId = Integer.parseInt(parts[0]);

                        // If current ID is greater than maxId, update maxId
                        if (currId > maxId) maxId = currId;
                    } catch (NumberFormatException ignored) {
                        // If parsing fails, ignore and continue
                    }
                }
            }
        } catch (IOException e) {
            // If reading file fails, ignore the exception and continue
        }

        // Return the next unique ID, which is maxId + 1
        return maxId + 1;
    }

    // Get the feedback ID
    public int getId() { return id; }

    // Set the feedback ID
    public void setId(int id) { this.id = id; }

    // Get the username of the citizen who gave feedback
    public String getUsername() { return username; }

    // Get the feedback message
    public String getMessage() { return message; }

    // Get the current status of the feedback
    public String getStatus() { return status; }

    // Set the status of the feedback
    public void setStatus(String status) { this.status = status; }

    // Get the creation time of the feedback
    public LocalDateTime getCreatedAt() { return createdAt; }

    // Get the filename of the image associated with the feedback
    public String getImageFilename() { return imageFilename; }

    // Set the filename of the image associated with the feedback
    public void setImageFilename(String imageFilename) { this.imageFilename = imageFilename; }

    // Override method from DatabaseOperations to save feedback to file
    @Override
    public boolean save() {
        // Try-with-resources to open the feedback file in append mode
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FilePaths.FEEDBACKS, true))) {
            // Replace any '|' characters in message with '/' to avoid file format issues
            String msg = (message != null ? message.replace("|", "/") : "");

            // Use empty string if there is no image filename
            String img = (imageFilename == null ? "" : imageFilename);

            // Write feedback fields separated by '|' to the file
            writer.write(id + "|" + username + "|" + msg + "|" + status + "|" + createdAt.toString() + "|" + img);

            // Add a new line after the entry
            writer.newLine();

            // Return true to indicate save was successful
            return true;
        } catch (IOException e) {
            // Return false if any IO exception occurs during save
            return false;
        }
    }

    @Override
    public boolean update() {
        // Method to update the feedback record in the feedbacks file

        File inputFile = new File(FilePaths.FEEDBACKS);
        // Reference to the original feedbacks file

        File tempFile = new File("feedbacks_temp.txt");
        // Temporary file to write the updated content

        boolean updated = false;
        // Flag to indicate whether the feedback was successfully updated

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            // Open reader for the original file and writer for the temporary file

            String line;
            // Variable to hold each line read from the file

            while ((line = reader.readLine()) != null) {
                // Read each line until end of file

                String[] parts = line.split("\\|");
                // Split the line by '|' to extract individual fields

                if (parts.length >= 5 && Integer.toString(id).equals(parts[0])) {
                    // Check if line has at least 5 parts and the feedback ID matches the current object's ID

                    writer.write(
                            id + "|" +                          // Write feedback ID
                                    username + "|" +                    // Write username
                                    (message != null ? message.replace("|", "/") : "") + "|" +  // Write message, replacing '|' to avoid delimiter conflicts
                                    status + "|" +                     // Write status
                                    createdAt.toString() + "|" +       // Write creation timestamp
                                    (imageFilename == null ? "" : imageFilename)  // Write image filename if available, else empty
                    );
                    updated = true;
                    // Mark that the update has occurred successfully
                } else {
                    writer.write(line);
                    // For other lines, just write them unchanged to the temporary file
                }

                writer.newLine();
                // Add a newline after writing each line
            }

        } catch (IOException e) {
            // If an IO exception occurs during reading or writing
            return false;
            // Indicate update failure
        }

        if (inputFile.delete() && tempFile.renameTo(inputFile)) {
            // If original file is deleted and temporary file renamed successfully
            return updated;
            // Return true if update happened, else false (if no matching record found)
        }

        return false;
        // Return false if file operations (delete/rename) failed
    }

    @Override
    public boolean delete() {
        // Method to delete the feedback record from the feedbacks file

        File inputFile = new File(FilePaths.FEEDBACKS);
        // Reference to the existing feedbacks data file

        File tempFile = new File("feedbacks_temp.txt");
        // Temporary file to write updated data without the deleted record

        boolean deleted = false;
        // Flag to indicate if the feedback record was found and deleted

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            // Open the original file for reading and the temp file for writing

            String line;
            // Variable to store each line read from the file

            while ((line = reader.readLine()) != null) {
                // Loop through each line in the original file

                String[] parts = line.split("\\|");
                // Split the line into parts using '|' delimiter

                if (parts.length >= 5 && Integer.toString(id).equals(parts[0])) {
                    // If the line has enough parts and the ID matches this feedback's ID

                    deleted = true;
                    // Mark that this record is to be deleted by skipping the write operation

                    continue;
                    // Skip writing this line to the temp file (effectively deleting it)
                }

                writer.write(line);
                // Write lines that do NOT match the ID to the temp file (keep them)

                writer.newLine();
                // Write a newline after each line to preserve file formatting
            }

        } catch (IOException e) {
            // If an error occurs during file reading or writing
            return false;
            // Return false indicating delete failure
        }

        if (inputFile.delete() && tempFile.renameTo(inputFile)) {
            // If original file is deleted and temp file renamed successfully
            return deleted;
            // Return true if a record was deleted, false if no matching record found
        }

        return false;
        // Return false if file replacement operations failed
    }


    // Static method to load all feedback entries for a specific user from the feedbacks file
    public static List<Feedback> loadFeedbacksForUser(String username) {
        List<Feedback> feedbacks = new ArrayList<>();
        // Create a list to store Feedback objects belonging to the specified user

        try (BufferedReader reader = new BufferedReader(new FileReader(FilePaths.FEEDBACKS))) {
            // Open the feedbacks file for reading using a BufferedReader (auto-close on exit)

            String line;
            // Variable to hold each line read from the file

            while ((line = reader.readLine()) != null) {
                // Loop through each line until end of file

                String[] parts = line.split("\\|");
                // Split the line into fields using '|' delimiter

                if ((parts.length == 6 || parts.length == 5) && parts[1].equals(username)) {
                    // Check if the line has 5 or 6 fields and the username field matches the given username

                    Feedback fb = new Feedback(
                            Integer.parseInt(parts[0]),   // Parse and pass the feedback ID
                            parts[1],                    // Username
                            parts[2],                    // Feedback message
                            parts[3],                    // Feedback status
                            LocalDateTime.parse(parts[4]), // Parse creation date/time
                            parts.length == 6 ? parts[5] : "" // Image filename if present, else empty string
                    );

                    feedbacks.add(fb);
                    // Add the created Feedback object to the list
                }
            }
        } catch (IOException e) {
            // If an error occurs during file reading, ignore it silently (could be logged if needed)
        }

        return feedbacks;
        // Return the list of feedbacks for the given user (empty if none found or error occurred)
    }


    // Static method to load all feedbacks
    public static List<Feedback> loadAllFeedbacks() {
        List<Feedback> feedbacks = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FilePaths.FEEDBACKS))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|", -1); // Use -1 to keep empty fields
                if (parts.length >= 5) {
                    Feedback fb = new Feedback(
                            Integer.parseInt(parts[0]),
                            parts[1],
                            parts[2],
                            parts[3],
                            LocalDateTime.parse(parts[4]),
                            parts.length > 5 ? parts[5] : ""
                    );
                    feedbacks.add(fb);
                }
            }
        } catch (IOException e) {}
        return feedbacks;
    }
}

// AdminResponse class
class AdminResponse implements DatabaseOperations {
    private int id; // Response ID
    private int feedbackId; // Feedback ID
    private String response; // Response text
    private LocalDateTime respondedAt; // Response time

    public AdminResponse(int feedbackId, String response) {
        this.feedbackId = feedbackId; // Set feedback ID
        this.response = response; // Set response text
        this.respondedAt = LocalDateTime.now(); // Set response time
        this.id = generateId(); // Generate unique ID
    }

    // Generate a unique ID for admin response
    private int generateId() {
        int maxId = 0;
        // Initialize maxId to 0, to track the highest existing ID found in the file

        try (BufferedReader reader = new BufferedReader(new FileReader(FilePaths.RESPONSES))) {
            // Open the responses file for reading using BufferedReader, auto-closed after use

            String line;
            // Variable to hold each line read from the file

            while ((line = reader.readLine()) != null) {
                // Loop through each line in the file until end of file

                String[] parts = line.split("\\|");
                // Split the line into parts based on '|' delimiter

                if (parts.length > 0) {
                    // Check if the line contains at least one part (to avoid empty lines)

                    try {
                        int currId = Integer.parseInt(parts[0]);
                        // Parse the first part (expected to be ID) as an integer

                        if (currId > maxId) maxId = currId;
                        // If the current ID is greater than maxId, update maxId to current ID
                    } catch (NumberFormatException ignored) {
                        // If parsing fails (invalid number), ignore and continue to next line
                    }
                }
            }
        } catch (IOException e) {
            // If an IOException occurs while reading the file, silently catch it (could be logged)
        }

        return maxId + 1;
        // Return the next unique ID by incrementing maxId by 1
    }


    @Override
    public boolean save() {
        // Save admin response to file by appending it to the responses file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FilePaths.RESPONSES, true))) {
            // Open the responses file in append mode with BufferedWriter (auto-close after use)

            // Write the response fields separated by '|', replacing any '|' in the response text to avoid delimiter conflicts
            writer.write(id + "|" + feedbackId + "|" + response.replace("|", "/") + "|" + respondedAt.toString());

            writer.newLine();
            // Add a newline after writing the response record

            return true;
            // Return true indicating successful save
        } catch (IOException e) {
            // If an IOException occurs during writing
            return false;
            // Return false indicating failure to save
        }
    }

    @Override
    public boolean update() {
        // Update admin response record in the responses file by rewriting the file with the updated entry
        File inputFile = new File(FilePaths.RESPONSES);
        // Reference to the original responses file

        File tempFile = new File("responses_temp.txt");
        // Temporary file to write updated content

        boolean updated = false;
        // Flag to indicate whether the update took place

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            // Open reader for original file and writer for temp file (auto-close after use)

            String line;
            // Variable to hold each line read from the original file

            while ((line = reader.readLine()) != null) {
                // Read each line until EOF

                String[] parts = line.split("\\|");
                // Split line by '|' delimiter into parts

                if (parts.length >= 4 && Integer.toString(id).equals(parts[0])) {
                    // Check if the line has at least 4 parts and the ID matches the current object's ID

                    // Write updated response data to the temp file, replacing any '|' in the response
                    writer.write(id + "|" + feedbackId + "|" + response.replace("|", "/") + "|" + respondedAt.toString());

                    updated = true;
                    // Mark that the update has occurred successfully
                } else {
                    writer.write(line);
                    // For other lines, write them unchanged to the temp file
                }

                writer.newLine();
                // Add a newline after each line written
            }
        } catch (IOException e) {
            // If an IOException occurs during reading or writing
            return false;
            // Return false indicating update failure
        }

        if (inputFile.delete() && tempFile.renameTo(inputFile)) {
            // Delete original file and rename temp file to original file name
            return updated;
            // Return true if update occurred, false if no matching record found
        }

        return false;
        // Return false if file deletion or renaming failed
    }


    @Override
    public boolean delete() {
        // Delete admin response by rewriting the RESPONSES file without the matching entry
        File inputFile = new File(FilePaths.RESPONSES);
        File tempFile = new File("responses_temp.txt");
        boolean deleted = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");

                // Check if line corresponds to the response to delete
                if (parts.length >= 4 && Integer.toString(id).equals(parts[0])) {
                    deleted = true; // Mark as deleted by skipping this line
                    continue;       // Skip writing this line to temp file
                }

                // Write unchanged lines back to the temp file
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            // Optional: log or print stack trace for debugging
            // e.printStackTrace();
            return false; // Return false on IO exception
        }

        // Replace original file with the updated temp file
        if (inputFile.delete() && tempFile.renameTo(inputFile)) {
            return deleted; // Return true if deletion occurred, false otherwise
        }

        return false; // Return false if file operations failed
    }


    // Static method to load all responses for a feedback
    public static List<AdminResponse> loadResponsesForFeedback(int feedbackId) {
        List<AdminResponse> responses = new ArrayList<>();
        // List to hold all AdminResponse objects matching the feedbackId

        try (BufferedReader reader = new BufferedReader(new FileReader(FilePaths.RESPONSES))) {
            // Open the responses file with BufferedReader (auto-close after use)

            String line;
            // Variable to store each line read from the file

            while ((line = reader.readLine()) != null) {
                // Loop through each line until end of file

                String[] parts = line.split("\\|");
                // Split the line into parts using '|' as delimiter

                if (parts.length >= 4 && Integer.toString(feedbackId).equals(parts[1])) {
                    // Check if the line has at least 4 parts and the feedbackId matches

                    AdminResponse ar = new AdminResponse(feedbackId, parts[2]);
                    // Create a new AdminResponse object using feedbackId and response message

                    ar.id = Integer.parseInt(parts[0]);
                    // Parse and assign the response ID from the first part

                    ar.respondedAt = LocalDateTime.parse(parts[3]);
                    // Parse and assign the response timestamp from the fourth part

                    responses.add(ar);
                    // Add the AdminResponse object to the responses list
                }
            }
        } catch (IOException e) {
            // Ignore IOException silently (optionally could log the error)
        }

        return responses;
        // Return the list of AdminResponse objects matching the feedbackId
    }

    // Add a public getter for response
    public String getResponse() { return response; }

    public int getId() { return id; }
}

/// Main application class for the Citizen Feedback System
public class CitizenFeedbackSystem {
    public static void main(String[] args) {
        try {
            // Set the GUI look and feel to the system's default theme
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Print any exceptions that occur while setting look and feel
            e.printStackTrace();
        }
        // Schedule the creation of the RoleSelectionScreen on the Event Dispatch Thread for thread safety
        SwingUtilities.invokeLater(() -> new RoleSelectionScreen());
    }
}


// GUI Classes
class RoleSelectionScreen extends JFrame {
    public RoleSelectionScreen() {
        setTitle("Citizen Feedback System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GuiUtils.sizeAndCenterWindow(this, 0.95, 0.95);
        setLayout(new BorderLayout());

        // --- Header with Title and Tagline (no image, no paragraph) ---
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(33, 56, 117));
        headerPanel.setPreferredSize(new Dimension(0, 120));
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 40, 0, 40)); // Add left/right padding
        JLabel headerLabel = new JLabel("Citizen Feedback System");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        headerPanel.add(Box.createVerticalStrut(12));
        headerPanel.add(headerLabel);
        headerPanel.add(Box.createVerticalStrut(6));
        JLabel tagline = new JLabel("<html><b>Empowering smart city living: seamless water, power, gas, and road services.<br>Progress, convenience, and quality of life for every citizen—24/7.</b></html>");
        tagline.setFont(new Font("Times New Roman", Font.BOLD, 20));
        tagline.setForeground(Color.WHITE);
        tagline.setAlignmentX(Component.LEFT_ALIGNMENT);
        headerPanel.add(tagline);
        add(headerPanel, BorderLayout.NORTH);

        // --- Main Content Panel ---
// Create the main panel with a BorderLayout to hold content sections
        JPanel mainPanel = new JPanel(new BorderLayout());
// Make the main panel transparent (not opaque) to show background through it
        mainPanel.setOpaque(false);


        // --- Feature Boxes Panel ---
        JPanel featuresPanel = new JPanel(new GridLayout(1, 4, 18, 0));
        featuresPanel.setOpaque(false);
        featuresPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 0, 40));
        featuresPanel.add(createFeatureBox("Water", "https://cdn-icons-png.flaticon.com/512/728/728093.png", "Clean water for all.<br>24/7 safe supply."));
        featuresPanel.add(createFeatureBox("Electricity", "https://cdn-icons-png.flaticon.com/512/169/169367.png", "Reliable power, always.<br>Bright homes, bright city."));
        featuresPanel.add(createFeatureBox("Gas", "https://cdn-icons-png.flaticon.com/512/3076/3076922.png", "Safe gas for cooking.<br>Instant support, anytime."));
        featuresPanel.add(createFeatureBox("Roads", "https://cdn-icons-png.flaticon.com/512/854/854878.png", "Smooth roads for all.<br>Report issues, drive safe."));
        mainPanel.add(featuresPanel, BorderLayout.CENTER);

        // --- Welcome and Buttons Panel ---
        JPanel bottomPanel = new JPanel(new GridBagLayout());
        bottomPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 10, 20, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel welcomeLabel = new JLabel("Welcome! Please select your role to continue.");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        welcomeLabel.setForeground(new Color(33, 56, 117));
        bottomPanel.add(welcomeLabel, gbc);
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        JButton adminBtn = new JButton("Admin Login");
        JButton userBtn = new JButton("Citizen Login");
        styleModernButton(adminBtn, new Color(41, 128, 185), new Color(31, 97, 141), "");
        styleModernButton(userBtn, new Color(39, 174, 96), new Color(30, 132, 73), "");
        bottomPanel.add(adminBtn, gbc);
        gbc.gridx = 1;
        bottomPanel.add(userBtn, gbc);
        adminBtn.addActionListener(e -> {
            new LoginForm(true);
            dispose();
        });
        userBtn.addActionListener(e -> {
            new LoginForm(false);
            dispose();
        });
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        add(mainPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    // Helper to create a feature box with icon and text, rounded corners, triangle accent, compact size
    private JPanel createFeatureBox(String title, String iconUrl, String desc) {
        JPanel box = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw triangle accent at the top
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth();
                int[] xPoints = {w/2-14, w/2, w/2+14};
                int[] yPoints = {14, 2, 14};
                g2.setColor(new Color(41, 128, 185));
                g2.fillPolygon(xPoints, yPoints, 3);
            }
        };
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        box.setPreferredSize(new Dimension(160, 150));
        box.setMaximumSize(new Dimension(180, 170));
        box.setBorder(BorderFactory.createCompoundBorder(
                new javax.swing.border.LineBorder(new Color(33, 56, 117), 2, true),
                BorderFactory.createEmptyBorder(18, 8, 8, 8)
        ));
        box.setAlignmentY(Component.CENTER_ALIGNMENT);
        JLabel iconLabel;
        try {
            ImageIcon icon = new ImageIcon(new java.net.URL(iconUrl));
            Image img = icon.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
            iconLabel = new JLabel(new ImageIcon(img));
        } catch (Exception e) {
            iconLabel = new JLabel();
        }
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        titleLabel.setForeground(new Color(33, 56, 117));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel descLabel = new JLabel("<html><div style='text-align:center;width:100px;'>" + desc + "</div></html>");
        descLabel.setFont(new Font("Times New Roman", Font.PLAIN, 13));
        descLabel.setForeground(new Color(44, 62, 80));
        descLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        box.add(Box.createVerticalStrut(6));
        box.add(iconLabel);
        box.add(Box.createVerticalStrut(6));
        box.add(titleLabel);
        box.add(Box.createVerticalStrut(4));
        box.add(descLabel);
        return box;
    }

    // --- Helper to style buttons ---
    public static void styleModernButton(JButton button, Color bg, Color hover, String iconText) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(bg);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18)); // smaller padding
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
        button.setText(button.getText()); // Remove iconText
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI());
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(hover);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bg);
            }
        });
    }
}

// LoginForm class that extends JFrame to create a login window
class LoginForm extends JFrame {
    // Text field for entering username
    private JTextField txtUsername;
    // Password field for entering password securely
    private JPasswordField txtPassword;
    // Flag to indicate if this form is for admin login or citizen login
    private boolean isAdminLogin;

    // Constructor that takes a boolean to set the login type (admin or citizen)
    public LoginForm(boolean isAdminLogin) {
        // Set the class-level variable to the passed value
        this.isAdminLogin = isAdminLogin;
        // Set the window title based on login type: "Admin Login" or "Citizen Login"
        setTitle(isAdminLogin ? "Admin Login" : "Citizen Login");
        // Set the default close operation to exit the application when the window is closed
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Set the window size to full screen (1 = 100%) and center it on the screen
        GuiUtils.sizeAndCenterWindow(this, 1, 1); // the size of both citizen and admin login page
        // Allow the user to resize the window
        setResizable(true);
        // Set the layout manager of the frame to BorderLayout for arranging components
        setLayout(new BorderLayout());

        // --- Modern Header Panel ---
// Create a new JPanel with BorderLayout to hold header components
        JPanel headerPanel = new JPanel(new BorderLayout());
// Set the background color of the header panel to a dark blue shade
        headerPanel.setBackground(new Color(33, 56, 117));
// Set preferred height of the header panel, width is flexible (0 means full width)
        headerPanel.setPreferredSize(new Dimension(0, 90));
// Create a JLabel for the header text, showing "Admin Login" or "Citizen Login" based on login type, aligned left
        JLabel headerLabel = new JLabel((isAdminLogin ? "  Admin Login" : "  Citizen Login"), JLabel.LEFT);
// Set the font of the header label to "Segoe UI", bold, size 26
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
// Set the text color of the header label to white
        headerLabel.setForeground(Color.WHITE);
// Add the header label to the left (WEST) side of the header panel
        headerPanel.add(headerLabel, BorderLayout.WEST);

        // --- Main Content Panel ---
// Create a new JPanel using GridBagLayout for flexible component placement
        JPanel mainPanel = new JPanel(new GridBagLayout()) {
            // Override the paintComponent method to customize the panel's background
            @Override
            protected void paintComponent(Graphics g) {
                // Call the superclass method to ensure proper painting of components
                super.paintComponent(g);
                // Cast the Graphics object to Graphics2D for advanced drawing features
                Graphics2D g2d = (Graphics2D) g;
                // Create a vertical gradient paint from top (light color) to bottom (slightly darker color)
                GradientPaint gp = new GradientPaint(0, 0, new Color(245, 247, 250), 0, getHeight(), new Color(220, 230, 245));
                // Set the paint of Graphics2D to the gradient created above
                g2d.setPaint(gp);
                // Fill the entire panel area with the gradient paint
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        // Make the main panel transparent so background gradient shows through
        mainPanel.setOpaque(false);

// Create GridBagConstraints object to control component layout in mainPanel
        GridBagConstraints gbc = new GridBagConstraints();

// Set padding (top, left, bottom, right) around components
        gbc.insets = new Insets(12, 10, 12, 10);

// Position the component at column 0, row 0
        gbc.gridx = 0;
        gbc.gridy = 0;

// Make the component span across 2 columns
        gbc.gridwidth = 2;

// Create a label with the welcome title text
        JLabel titleLabel = new JLabel("Welcome to Citizen Feedback System");

// Set font style and size for the title label
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));

// Set the color of the title text
        titleLabel.setForeground(new Color(33, 56, 117));

// Add the title label to mainPanel at the specified grid position and width
        mainPanel.add(titleLabel, gbc);

// Reset grid width to 1 for subsequent components
        gbc.gridwidth = 1;

// Move to the next row (row 1)
        gbc.gridy = 1;

// Position component in column 0
        gbc.gridx = 0;

// Create label for "Username:"
        JLabel lblUsername = new JLabel("Username:");

// Set font style and size for the username label
        lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 16));

// Add username label to the panel at specified position
        mainPanel.add(lblUsername, gbc);

// Initialize the username text field with width 18 columns
        txtUsername = new JTextField(18);

// Move to column 1 to place the text field next to its label
        gbc.gridx = 1;

// Add the username text field to the panel
        mainPanel.add(txtUsername, gbc);

// Move to next row (row 2)
        gbc.gridy = 2;

// Position component in column 0
        gbc.gridx = 0;

// Create label for "Password:"
        JLabel lblPassword = new JLabel("Password:");

// Set font style and size for the password label
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 16));

// Add password label to the panel
        mainPanel.add(lblPassword, gbc);

// Initialize the password field with width 18 columns
        txtPassword = new JPasswordField(18);

// Move to column 1 for password input field
        gbc.gridx = 1;

// Add password field to the panel
        mainPanel.add(txtPassword, gbc);

// Create the Login button
        JButton btnLogin = new JButton("Login");

// Create the Back button
        JButton btnBack = new JButton("Back");

// Style the Login button with blue shades and a lock icon
        RoleSelectionScreen.styleModernButton(btnLogin, new Color(41, 128, 185), new Color(31, 97, 141), "\uD83D\uDD13"); // 🔓

// Style the Back button with gray shades and a left arrow icon
        RoleSelectionScreen.styleModernButton(btnBack, new Color(189, 195, 199), new Color(127, 140, 141), "\u2B05"); // ⬅

// Set the text color of the Back button to black for better contrast
        btnBack.setForeground(Color.BLACK);

// Position buttons panel at column 0, row 3 spanning 2 columns
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;

// Create a JPanel for buttons with centered flow layout and spacing between buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));

// Make buttons panel transparent to show main panel background
        btnPanel.setOpaque(false);

// Add Login button to buttons panel
        btnPanel.add(btnLogin);

// Add Back button to buttons panel
        btnPanel.add(btnBack);

// Add buttons panel to mainPanel using GridBagConstraints
        mainPanel.add(btnPanel, gbc);

// Add event listener for Login button to call login handling method when clicked
        btnLogin.addActionListener(e -> handleLogin());

// Add event listener for Back button to return to role selection screen and close login form
        btnBack.addActionListener(e -> {
            new RoleSelectionScreen();
            dispose();
        });


        // Add the mainPanel to the center of the JFrame's BorderLayout
        add(mainPanel, BorderLayout.CENTER);

// Make the JFrame visible on the screen
        setVisible(true);
    }

    // Method to handle login logic when Login button is clicked
    private void handleLogin() {
        // Get the entered username from the username text field
        String username = txtUsername.getText();

        // Get the entered password from the password field as a String
        String password = new String(txtPassword.getPassword());

        try {
            // Check if this is an admin login attempt
            if (isAdminLogin) {
                // Create an Admin object with the entered credentials
                Admin admin = new Admin(username, password);

                // If admin credentials are valid
                if (admin.login()) {
                    // Show a welcome message to the admin
                    JOptionPane.showMessageDialog(this, "Welcome Admin!");

                    // Open the AdminDashboard window
                    new AdminDashboard();

                    // Close the current login window
                    dispose();
                } else {
                    // Show error message for invalid admin credentials
                    JOptionPane.showMessageDialog(this, "Invalid Admin Credentials");
                }
            } else {
                // For citizen login, create a Citizen object
                // Here, the third parameter (name) is set to username for simplicity
                Citizen citizen = new Citizen(username, password, username);

                // If citizen credentials are valid
                if (citizen.login()) {
                    // Show a welcome message including the citizen's name
                    JOptionPane.showMessageDialog(this, "Welcome " + citizen.getName());

                    // Open the FeedbackForm window, passing the logged-in citizen
                    new FeedbackForm(citizen);

                    // Close the current login window
                    dispose();
                } else {
                    // Show error message for invalid citizen credentials
                    JOptionPane.showMessageDialog(this, "Invalid Citizen Credentials");
                }
            }
        } catch (Exception ex) {
            // Show any unexpected errors in a message dialog
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}


// RegistrationForm class for new citizen registrations
class RegistrationForm extends JFrame {
    // Text field for entering username
    private JTextField txtUsername;

    // Password field for entering password
    private JPasswordField txtPassword;

    // Text field for entering full name
    private JTextField txtName;

    // Text field for entering email address
    private JTextField txtEmail;

    // Text field for entering phone number
    private JTextField txtPhone;

    // Constructor to initialize the registration form window
    public RegistrationForm() {
        // Set the title of the JFrame window
        setTitle("Citizen Registration");

        // Define the default close operation to exit the app when closed
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set size and center the window (40% width, 60% height of screen)
        GuiUtils.sizeAndCenterWindow(this, 0.4, 0.6);

        // Use BorderLayout for the main frame layout
        setLayout(new BorderLayout());

        // --- Modern Header ---
// Create a header panel with BorderLayout
        JPanel headerPanel = new JPanel(new BorderLayout());
// Set background color to a dark blue shade
        headerPanel.setBackground(new Color(33, 56, 117));
// Set preferred height of the header panel to 90 pixels (width flexible)
        headerPanel.setPreferredSize(new Dimension(0, 90));
// Create a label with the text "Citizen Registration" aligned to the left
        JLabel headerLabel = new JLabel("  Citizen Registration", JLabel.LEFT);
// Set the font to Segoe UI, bold, size 26
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
// Set the font color to white
        headerLabel.setForeground(Color.WHITE);
// Add the label to the left side (WEST) of the header panel
        headerPanel.add(headerLabel, BorderLayout.WEST);

// --- Main Content Panel ---
// Create main content panel using GridBagLayout for flexible component placement
        JPanel mainPanel = new JPanel(new GridBagLayout()) {
            // Override paintComponent to paint a vertical gradient background
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Cast Graphics to Graphics2D for advanced drawing features
                Graphics2D g2d = (Graphics2D) g;
                // Create a vertical gradient from light grayish-blue at top to slightly darker at bottom
                GradientPaint gp = new GradientPaint(0, 0, new Color(245, 247, 250), 0, getHeight(), new Color(220, 230, 245));
                // Set the paint to the gradient
                g2d.setPaint(gp);
                // Fill the entire panel area with the gradient
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        mainPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 10, 12, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        JLabel titleLabel = new JLabel("Citizen Registration");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(new Color(33, 56, 117));
        mainPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        mainPanel.add(lblUsername, gbc);
        txtUsername = new JTextField(18);
        gbc.gridx = 1;
        mainPanel.add(txtUsername, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        mainPanel.add(lblPassword, gbc);
        txtPassword = new JPasswordField(18);
        gbc.gridx = 1;
        mainPanel.add(txtPassword, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel lblName = new JLabel("Full Name:");
        lblName.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        mainPanel.add(lblName, gbc);
        txtName = new JTextField(18);
        gbc.gridx = 1;
        mainPanel.add(txtName, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        mainPanel.add(lblEmail, gbc);
        txtEmail = new JTextField(18);
        gbc.gridx = 1;
        mainPanel.add(txtEmail, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        JLabel lblPhone = new JLabel("Phone:");
        lblPhone.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        mainPanel.add(lblPhone, gbc);
        txtPhone = new JTextField(18);
        gbc.gridx = 1;
        mainPanel.add(txtPhone, gbc);

        JButton btnRegister = new JButton("Register");
        JButton btnBack = new JButton("Back");
        RoleSelectionScreen.styleModernButton(btnRegister, new Color(39, 174, 96), new Color(30, 132, 73), "\uD83D\uDCDD"); // 📝
        RoleSelectionScreen.styleModernButton(btnBack, new Color(189, 195, 199), new Color(127, 140, 141), "\u2B05"); // ⬅
        btnBack.setForeground(Color.BLACK);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        btnPanel.setOpaque(false);
        btnPanel.add(btnRegister);
        btnPanel.add(btnBack);
        mainPanel.add(btnPanel, gbc);

        btnRegister.addActionListener(e -> handleRegistration());
        btnBack.addActionListener(e -> {
            new RoleSelectionScreen();
            dispose();
        });

        add(mainPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private void handleRegistration() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());
        String name = txtName.getText();
        String email = txtEmail.getText();
        String phone = txtPhone.getText();

        if (username.isEmpty() || password.isEmpty() || name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields");
            return;
        }

        try {
            Citizen citizen = new Citizen(username, password, name);
            citizen.setEmail(email);
            citizen.setPhone(phone);

            if (citizen.save()) {
                JOptionPane.showMessageDialog(this, "Registration successful!");
                new LoginForm(false);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Registration failed. Username might already exist.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}

// FeedbackForm class
class FeedbackForm extends JFrame {
    private Citizen citizen;
    private JTextArea txtFeedback;
    private JTable feedbackTable;
    private DefaultTableModel tableModel;

    public FeedbackForm(Citizen citizen) {
        this.citizen = citizen;
        setTitle("Submit Feedback - " + citizen.getName());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GuiUtils.sizeAndCenterWindow(this, 1, 1);
        setLayout(new BorderLayout());

        // --- Modern Header ---
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(33, 56, 117));
        headerPanel.setPreferredSize(new Dimension(0, 100));
        JLabel headerLabel = new JLabel("  Submit Feedback", JLabel.LEFT);
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel, BorderLayout.WEST);

        // --- Main Content Panel ---
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(245, 247, 250), 0, getHeight(), new Color(220, 230, 245));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setOpaque(false);

        // --- Feedback Input Section ---
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.setOpaque(false);

        JLabel lblFeedback = new JLabel("Enter your feedback:");
        lblFeedback.setFont(new Font("Segoe UI", Font.BOLD, 16));
        inputPanel.add(lblFeedback, BorderLayout.NORTH);

        txtFeedback = new JTextArea(5, 40);
        txtFeedback.setLineWrap(true);
        txtFeedback.setWrapStyleWord(true);
        txtFeedback.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        inputPanel.add(new JScrollPane(txtFeedback), BorderLayout.CENTER);

        // --- Feedback History Section ---
        JPanel historyPanel = new JPanel(new BorderLayout());
        historyPanel.setBorder(BorderFactory.createTitledBorder("Your Feedback History"));
        historyPanel.setOpaque(false);
        String[] columns = {"Date", "Feedback", "Status", "Response"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        feedbackTable = new JTable(tableModel);
        feedbackTable.setRowHeight(60);
        feedbackTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        feedbackTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
        historyPanel.add(new JScrollPane(feedbackTable), BorderLayout.CENTER);

        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(historyPanel, BorderLayout.CENTER);

        // --- Bottom Buttons ---
        JButton btnSubmit = new JButton("Submit Feedback");
        JButton btnLogout = new JButton("Logout");
        RoleSelectionScreen.styleModernButton(btnSubmit, new Color(39, 174, 96), new Color(30, 132, 73), "\uD83D\uDCE9"); // 📩
        RoleSelectionScreen.styleModernButton(btnLogout, new Color(189, 195, 199), new Color(127, 140, 141), "\u23CF"); // ⏏
        btnLogout.setForeground(Color.BLACK);
        btnSubmit.addActionListener(e -> handleFeedbackSubmission());
        btnLogout.addActionListener(e -> {
            new RoleSelectionScreen();
            dispose();
        });
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 10));
        buttonPanel.setOpaque(false);
        buttonPanel.add(btnSubmit);
        buttonPanel.add(btnLogout);

        add(mainPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        loadFeedbackHistory();
        setVisible(true);
    }

    private void handleFeedbackSubmission() {
        String feedback = txtFeedback.getText().trim();
        if (feedback.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your feedback message.");
            return;
        }
        try {
            Feedback newFeedback = new Feedback(citizen.getUsername(), feedback);
            newFeedback.setImageFilename(null);
            if (newFeedback.save()) {
                JOptionPane.showMessageDialog(this, "Feedback submitted successfully!");
                txtFeedback.setText("");
                loadFeedbackHistory();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to submit feedback");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void loadFeedbackHistory() {
        tableModel.setRowCount(0);
        try {
            List<Feedback> feedbacks = Feedback.loadFeedbacksForUser(citizen.getUsername());
            for (Feedback fb : feedbacks) {
                List<AdminResponse> responses = AdminResponse.loadResponsesForFeedback(fb.getId());
                String responseText = "";
                if (!responses.isEmpty()) {
                    StringBuilder sb = new StringBuilder();
                    for (AdminResponse ar : responses) {
                        sb.append(ar.getResponse()).append("\n");
                    }
                    responseText = sb.toString().trim();
                }
                Object[] row = {
                        fb.getCreatedAt(),
                        fb.getMessage(),
                        fb.getStatus(),
                        responseText
                };
                tableModel.addRow(row);
            }
            feedbackTable.getColumnModel().getColumn(1).setPreferredWidth(250);
            feedbackTable.getColumnModel().getColumn(3).setPreferredWidth(250);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}

// AdminDashboard class – This is the main window for admin actions like viewing and responding to feedback
class AdminDashboard extends JFrame {

    // Table component to display all feedback entries in a tabular format
    private JTable feedbackTable;

    // Table model used to store data shown in feedbackTable
    private DefaultTableModel tableModel;

    // Text area where admin can type a response to selected feedback
    private JTextArea responseArea;

    // Holds the ID of the currently selected feedback; -1 means none selected
    private int selectedFeedbackId = -1;

    // Label at the bottom of the window to show messages or status updates
    private JLabel statusBar;

    public AdminDashboard() {
        setTitle("Admin Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GuiUtils.sizeAndCenterWindow(this, 1, 1);// the size of admin dashboard page
        setLayout(new BorderLayout());

        // --- Modern Header (no image) ---
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(33, 56, 117));
        headerPanel.setPreferredSize(new Dimension(0, 100));
        JLabel headerLabel = new JLabel("  Admin Dashboard", JLabel.LEFT);
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // --- Main Content Panel ---
        JPanel mainPanel = new JPanel(new BorderLayout()) { // Create a new JPanel with BorderLayout to organize components
            @Override
            protected void paintComponent(Graphics g) { // Override paintComponent to customize background
                super.paintComponent(g); // Call parent class method to retain default behavior
                Graphics2D g2d = (Graphics2D) g; // Cast Graphics to Graphics2D for advanced drawing
                GradientPaint gp = new GradientPaint(0, 0, new Color(245, 247, 250), 0, getHeight(), new Color(220, 230, 245));
                // Create a vertical gradient from top (light color) to bottom (darker color)
                g2d.setPaint(gp); // Set the gradient as the current paint
                g2d.fillRect(0, 0, getWidth(), getHeight()); // Fill the panel with the gradient color
            }
        };

        mainPanel.setOpaque(false);

        // Add columns for Feedback only (remove Response column)
        String[] columns = {"ID", "Status", "Citizen", "Date", "Feedback"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        feedbackTable = new JTable(tableModel);
        feedbackTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        feedbackTable.setRowHeight(60);
        feedbackTable.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        feedbackTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 16));
        // Add mouse click listener for image viewing
        feedbackTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int column = feedbackTable.getColumnModel().getColumnIndexAtX(e.getX());
                int row = e.getY() / feedbackTable.getRowHeight();
                if (row < feedbackTable.getRowCount() && row >= 0 && column == 4) { // Image column
                    String filename = (String) tableModel.getValueAt(row, 4);
                    if (filename != null && !filename.isEmpty()) {
                        showFullSizeImage(filename);
                    }
                }
            }
        });

        feedbackTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = feedbackTable.getSelectedRow();
                if (row != -1) {
                    selectedFeedbackId = (int) tableModel.getValueAt(row, 0);
                    responseArea.setEditable(true); // Make response area editable when a feedback is selected
                    loadFeedbackResponses(selectedFeedbackId);
                } else {
                    responseArea.setEditable(false);
                }
            }
        });

        JScrollPane tableScrollPane = new JScrollPane(feedbackTable);
        tableScrollPane.setBorder(BorderFactory.createTitledBorder("Feedback List"));

        responseArea = new JTextArea(5, 40);
        responseArea.setLineWrap(true);
        responseArea.setWrapStyleWord(true);
        responseArea.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        responseArea.setEditable(false);
        JScrollPane responseScrollPane = new JScrollPane(responseArea);
        responseScrollPane.setBorder(BorderFactory.createTitledBorder("Admin Response"));

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tableScrollPane, responseScrollPane);
        splitPane.setResizeWeight(0.7);
        mainPanel.add(splitPane, BorderLayout.CENTER);

        // --- Bottom Buttons ---
        JButton btnSubmit = new JButton("Submit Response");
        JButton btnUpdateStatus = new JButton("Update Status");
        JButton btnAddAdmin = new JButton("Add Admin");
        JButton btnLogout = new JButton("Logout");
        JButton btnAddCitizen = new JButton("Add Citizen");
        RoleSelectionScreen.styleModernButton(btnSubmit, new Color(41, 128, 185), new Color(31, 97, 141), "\uD83D\uDCE8"); // 📨
        RoleSelectionScreen.styleModernButton(btnUpdateStatus, new Color(39, 174, 96), new Color(30, 132, 73), "\u2705"); // ✅
        RoleSelectionScreen.styleModernButton(btnAddAdmin, new Color(52, 152, 219), new Color(41, 128, 185), "\u2795"); // ➕
        RoleSelectionScreen.styleModernButton(btnLogout, new Color(189, 195, 199), new Color(127, 140, 141), "\u23CF"); // ⏏
        RoleSelectionScreen.styleModernButton(btnAddCitizen, new Color(52, 152, 219), new Color(41, 128, 185), "\u2795"); // ➕
        btnLogout.setForeground(Color.BLACK);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setOpaque(false);
        buttonPanel.add(btnSubmit);
        buttonPanel.add(btnUpdateStatus);
        buttonPanel.add(btnAddAdmin);
        buttonPanel.add(btnAddCitizen);
        buttonPanel.add(btnLogout);
        responseArea.setEditable(false);

        // Add status bar
        statusBar = new JLabel("Ready");
        statusBar.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        // Combine button panel and status bar into a single bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(buttonPanel, BorderLayout.CENTER);
        bottomPanel.add(statusBar, BorderLayout.SOUTH);

        // Add panels in correct order
        add(headerPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH); // Only one bottom panel!
        loadFeedbackList();
        statusBar.setText("Feedback loaded successfully.");
        setVisible(true);

        // --- Ensure all button actions are set up correctly ---
        btnSubmit.addActionListener(e -> handleResponseSubmission());
        btnUpdateStatus.addActionListener(e -> handleStatusUpdate());
        btnAddAdmin.addActionListener(e -> {
            String newAdmin = JOptionPane.showInputDialog(this, "Enter new admin username:");
            if (newAdmin != null && !newAdmin.trim().isEmpty()) {
                String newPass = JOptionPane.showInputDialog(this, "Enter password for new admin:");
                if (newPass != null && !newPass.trim().isEmpty()) {
                    Admin admin = new Admin(newAdmin, newPass);
                    if (admin.save()) {
                        JOptionPane.showMessageDialog(this, "Admin added successfully!");
                        statusBar.setText("Admin added successfully!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to add admin (maybe already exists).");
                        statusBar.setText("Failed to add admin (maybe already exists).");
                    }
                }
            }
        });
        btnAddCitizen.addActionListener(e -> {
            JTextField usernameField = new JTextField();
            JTextField passwordField = new JTextField();
            JTextField nameField = new JTextField();
            JTextField emailField = new JTextField();
            JTextField phoneField = new JTextField();
            JPanel panel = new JPanel(new GridLayout(0, 1));
            panel.add(new JLabel("Username:"));
            panel.add(usernameField);
            panel.add(new JLabel("Password:"));
            panel.add(passwordField);
            panel.add(new JLabel("Full Name:"));
            panel.add(nameField);
            panel.add(new JLabel("Email:"));
            panel.add(emailField);
            panel.add(new JLabel("Phone:"));
            panel.add(phoneField);
            int result = JOptionPane.showConfirmDialog(this, panel, "Register New Citizen", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result == JOptionPane.OK_OPTION) {
                String username = usernameField.getText().trim();
                String password = passwordField.getText().trim();
                String name = nameField.getText().trim();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                if (username.isEmpty() || password.isEmpty() || name.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill in all required fields");
                    statusBar.setText("Please fill in all required fields");
                    return;
                }
                Citizen citizen = new Citizen(username, password, name);
                citizen.setEmail(email);
                citizen.setPhone(phone);
                if (citizen.save()) {
                    JOptionPane.showMessageDialog(this, "Citizen registered successfully!");
                    statusBar.setText("Citizen registered successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Registration failed. Username might already exist.");
                    statusBar.setText("Registration failed. Username might already exist.");
                }
            }
        });
        btnLogout.addActionListener(e -> {
            new RoleSelectionScreen();
            dispose();
        });

        // --- Ensure table selection works ---
        feedbackTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = feedbackTable.getSelectedRow();
                if (row != -1) {
                    selectedFeedbackId = (int) tableModel.getValueAt(row, 0);
                    responseArea.setEditable(true);
                    loadFeedbackResponses(selectedFeedbackId);
                } else {
                    responseArea.setEditable(false);
                }
            }
        });
    }

    private void loadFeedbackList() {
        tableModel.setRowCount(0);
        try {
            List<Feedback> feedbacks = Feedback.loadAllFeedbacks();
            for (Feedback fb : feedbacks) {
                Object[] row = {
                        fb.getId(),
                        fb.getStatus(),
                        fb.getUsername(),
                        fb.getCreatedAt(),
                        fb.getMessage() // Feedback column (citizen's message)
                };
                tableModel.addRow(row);
            }
            statusBar.setText("Feedback loaded successfully.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            statusBar.setText("Error loading feedback: " + ex.getMessage());
        }
    }

    private void loadFeedbackResponses(int feedbackId) {
        responseArea.setText("");
        try {
            List<AdminResponse> responses = AdminResponse.loadResponsesForFeedback(feedbackId);
            for (AdminResponse ar : responses) {
                responseArea.append(ar.getResponse() + "\n\n");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void handleResponseSubmission() {
        if (selectedFeedbackId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a feedback first");
            statusBar.setText("Please select a feedback first");
            return;
        }

        String response = responseArea.getText().trim();
        if (response.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a response");
            statusBar.setText("Please enter a response");
            return;
        }

        try {
            AdminResponse adminResponse = new AdminResponse(selectedFeedbackId, response);
            if (adminResponse.save()) {
                JOptionPane.showMessageDialog(this, "Response submitted successfully!");
                loadFeedbackResponses(selectedFeedbackId);
                statusBar.setText("Response submitted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to submit response");
                statusBar.setText("Failed to submit response");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            statusBar.setText("Error: " + ex.getMessage());
        }
    }

    private void handleStatusUpdate() {
        if (selectedFeedbackId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a feedback first");
            statusBar.setText("Please select a feedback first");
            return;
        }

        String[] statuses = {"Pending", "In Progress", "Resolved", "Closed"};
        String selectedStatus = (String) JOptionPane.showInputDialog(
                this,
                "Select new status:",
                "Update Status",
                JOptionPane.QUESTION_MESSAGE,
                null,
                statuses,
                statuses[0]
        );

        if (selectedStatus != null) {
            try {
                List<Feedback> feedbacks = Feedback.loadAllFeedbacks();
                for (Feedback fb : feedbacks) {
                    if (fb.getId() == selectedFeedbackId) {
                        fb.setStatus(selectedStatus);
                        fb.update();
                        break;
                    }
                }
                JOptionPane.showMessageDialog(this, "Status updated successfully!");
                loadFeedbackList();
                statusBar.setText("Status updated successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
                statusBar.setText("Error: " + ex.getMessage());
            }
        }
    }

    private void showFullSizeImage(String imagePath) {
        JDialog dialog = new JDialog(this, "Image Preview", true);
        dialog.setLayout(new BorderLayout());
        ImageIcon icon = new ImageIcon(imagePath);
        JLabel imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(JLabel.CENTER);
        Image img = icon.getImage();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int maxW = (int)(screenSize.width * 0.8);
        int maxH = (int)(screenSize.height * 0.8);
        int imgW = icon.getIconWidth();
        int imgH = icon.getIconHeight();
        if (imgW > maxW || imgH > maxH) {
            double scale = Math.min((double)maxW/imgW, (double)maxH/imgH);
            imgW = (int)(imgW * scale);
            imgH = (int)(imgH * scale);
            img = img.getScaledInstance(imgW, imgH, Image.SCALE_SMOOTH);
        }
        imageLabel.setIcon(new ImageIcon(img));
        JScrollPane scrollPane = new JScrollPane(imageLabel);
        scrollPane.setPreferredSize(new Dimension(Math.min(imgW+20, maxW), Math.min(imgH+20, maxH)));
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dialog.dispose());
        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(closeButton, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
}

// Utility method for sizing and centering windows
class GuiUtils {

    // A static method to resize and center any window (like JFrame or JDialog)
    public static void sizeAndCenterWindow(Window win, double percentW, double percentH) {

        // Get the screen size (width and height of the monitor)
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();

        // Calculate the new width using the given percentage of screen width
        int w = (int)(screen.width * percentW);

        // Calculate the new height using the given percentage of screen height
        int h = (int)(screen.height * percentH);

        // Set the new size of the window
        win.setSize(w, h);

        // Center the window on the screen
        win.setLocationRelativeTo(null);
    }
}
